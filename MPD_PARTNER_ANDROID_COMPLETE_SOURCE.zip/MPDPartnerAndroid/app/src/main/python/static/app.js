const view = document.getElementById("view");
const nav = document.getElementById("nav");

const NAV_ITEMS = [
  ["home", "Home"],
  ["job", "Job Brain"],
  ["quickupdate", "Quick Update"],
  ["catchmeup", "Catch Me Up"],
  ["whatchanged", "What Changed"],
  ["sincelasttour", "Since Last Tour"],
  ["watchlist", "Watch List"],
  ["meeting", "Meeting Mode"],
  ["decisionlog", "Decision Log"],
  ["critical", "Critical Event"],
  ["playbook", "Field Playbook"],
  ["whatdoisay", "What Do I Say"],
  ["competency", "Competency"],
  ["calculators", "Calculators"],
  ["pretour", "Pre-Tour"],
  ["barriers", "Barriers"],
  ["handover", "Handover"],
  ["glossary", "Glossary"],
];

function renderNav(active) {
  nav.innerHTML = "";
  NAV_ITEMS.forEach(([key, label]) => {
    const b = document.createElement("button");
    b.textContent = label;
    if (key === active) b.classList.add("active");
    b.onclick = () => go(key);
    nav.appendChild(b);
  });
}

async function api(path, method = "GET", body) {
  const opts = { method };
  if (body !== undefined) {
    opts.headers = { "Content-Type": "application/json" };
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(path, opts);
  return res.json();
}

function fmtTime(iso) {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  } catch {
    return iso;
  }
}

function nc(val) {
  return val ? val : '<span class="notconfigured">NOT CONFIGURED — VERIFY APPROVED JOB DOCUMENTATION</span>';
}

// ---------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------
const VIEWS = {
  home: renderHome,
  job: renderJob,
  quickupdate: renderQuickUpdate,
  catchmeup: renderCatchMeUp,
  whatchanged: renderWhatChanged,
  sincelasttour: renderSinceLastTour,
  watchlist: renderWatchList,
  meeting: renderMeeting,
  decisionlog: renderDecisionLog,
  critical: renderCritical,
  playbook: renderPlaybook,
  whatdoisay: renderWhatDoISay,
  competency: renderCompetency,
  calculators: renderCalculators,
  pretour: renderPreTour, barriers: renderBarriers, handover: renderHandover, glossary: renderGlossary,
};

function go(key) {
  renderNav(key);
  view.innerHTML = '<p class="muted">Loading…</p>';
  VIEWS[key]();
  window.scrollTo(0, 0);
}

// ---------------------------------------------------------------------
// HOME
// ---------------------------------------------------------------------
function renderHome() {
  view.innerHTML = `
    <h1>MPD PARTNER</h1>
    <p class="sub">Your personal MPD Wellsite Engineer field companion. Runs fully offline on this laptop.</p>
    <div class="grid-home">
      <button class="home-btn" onclick="go('catchmeup')">CATCH ME UP<small>What happened since your last update</small></button>
      <button class="home-btn" onclick="go('quickupdate')">QUICK UPDATE<small>Fastest possible status entry</small></button>
      <button class="home-btn" onclick="go('sincelasttour')">SINCE LAST TOUR<small>Compare shift start to now</small></button>
      <button class="home-btn" onclick="go('whatchanged')">WHAT CHANGED?<small>Latest vs previous parameters</small></button>
      <button class="home-btn" onclick="go('watchlist')">WATCH LIST<small>Open items to keep an eye on</small></button>
      <button class="home-btn" onclick="go('meeting')">MEETING IN 2 MINUTES<small>Instant status briefing</small></button>
      <button class="home-btn" onclick="go('decisionlog')">DECISION / EVENT LOG<small>Your professional memory</small></button>
      <button class="home-btn" onclick="go('critical')">CRITICAL EVENT MODE<small>Structured thinking when something's wrong</small></button>
      <button class="home-btn" onclick="go('playbook')">FIELD PLAYBOOK<small>Operation-by-operation reference</small></button>
      <button class="home-btn" onclick="go('whatdoisay')">WHAT DO I SAY?<small>Communication templates</small></button>
      <button class="home-btn" onclick="go('competency')">COMPETENCY TRACKER<small>What you actually know vs. what you've studied</small></button>
      <button class="home-btn" onclick="go('job')">JOB BRAIN<small>Rig, well, and job configuration</small></button>
      <button class="home-btn" onclick="go('calculators')">CALCULATORS<small>Hydrostatic, EMW, capacities, lag, conversions</small></button>
    </div>
    <p class="muted" style="margin-top:24px; font-size:13px;">
      This tool helps you understand the operation, remember the history, recognize changes, organize evidence,
      and communicate clearly. It is not an autonomous well-control system and does not replace the MPD Supervisor,
      Driller, Company Representative, or approved procedures.
    </p>
  `;
}

// ---------------------------------------------------------------------
// JOB BRAIN
// ---------------------------------------------------------------------
async function renderJob() {
  const job = await api("/api/job");
  const fields = [
    ["rig_name", "Rig Name"], ["rig_type", "Rig Type"], ["operator", "Operator"],
    ["well_name", "Well Name"], ["location", "Location"], ["units", "Units"],
    ["hole_sections", "Hole Sections"], ["casing_program", "Casing / Liner Program"],
    ["current_section", "Current Section"], ["mud_system", "Mud System"],
    ["current_mud_weight", "Current Mud Weight"],
    ["mpd_config", "MPD System Configuration"], ["rcd_config", "RCD Configuration"],
    ["choke_arrangement", "Choke Arrangement"],
    ["sensor_locations", "Sensor Locations"],
    ["flow_measurement_locations", "Flow Measurement Locations"],
    ["pressure_measurement_locations", "Pressure Measurement Locations"],
    ["gas_handling_arrangement", "Gas-Handling Arrangement"],
    ["key_personnel", "Key Personnel"], ["communication_hierarchy", "Communication Hierarchy"],
    ["approved_operating_limits", "Approved Operating Limits (from authorized documents)"],
    ["procedure_references", "Relevant Procedure References"],
  ];
  view.innerHTML = `
    <h1>Job Brain</h1>
    <p class="sub">Set up once per job. This never invents limits — leave a field blank if it isn't in an approved document yet.</p>
    <div class="card">
      ${fields.map(([key, label]) => `
        <div class="field-row wide">
          <div>
            <label>${label}</label>
            <textarea id="f_${key}" rows="1">${job[key] || ""}</textarea>
          </div>
        </div>
      `).join("")}
      <div class="actions">
        <button class="primary" onclick="saveJob()">Save Job Brain</button>
      </div>
    </div>
  `;
  window._jobFields = fields.map(f => f[0]);
}

async function saveJob() {
  const body = {};
  window._jobFields.forEach(k => body[k] = document.getElementById("f_" + k).value);
  await api("/api/job", "POST", body);
  go("job");
}

// ---------------------------------------------------------------------
// QUICK UPDATE
// ---------------------------------------------------------------------
function renderQuickUpdate() {
  view.innerHTML = `
    <h1>Quick Update</h1>
    <p class="sub">Fastest possible input. Fill in what you know — leave the rest blank.</p>
    <div class="card">
      <div class="field-row">
        <div><label>Operation</label><input id="q_operation" placeholder="e.g. Drilling ahead, 8.5&quot; hole"></div>
        <div><label>Depth</label><input id="q_depth" placeholder="e.g. 14,280 ft"></div>
      </div>
      <div class="field-row">
        <div><label>Pump Rate</label><input id="q_pump_rate" placeholder="e.g. 650 gpm"></div>
        <div><label>SBP</label><input id="q_sbp" placeholder="e.g. 435 psi"></div>
      </div>
      <div class="field-row">
        <div><label>SPP</label><input id="q_spp" placeholder="optional"></div>
        <div><label>Flow Out</label><input id="q_flow_out" placeholder="e.g. stable"></div>
      </div>
      <div class="field-row">
        <div><label>Pit Volume</label><input id="q_pit_volume" placeholder="e.g. stable / +1.2 bbl"></div>
        <div><label>Equipment Status</label><input id="q_equipment_status" placeholder="optional"></div>
      </div>
      <div class="field-row wide">
        <div><label>Notes</label><textarea id="q_notes" placeholder="Anything else worth remembering"></textarea></div>
      </div>
      <div class="actions">
        <button class="primary" onclick="submitUpdate('update')">Save Update</button>
        <button class="secondary" onclick="submitUpdate('event')">Log as Event</button>
        <button class="secondary" onclick="submitUpdate('tour_start')">Mark Tour Start</button>
      </div>
    </div>
  `;
}

async function submitUpdate(entryType) {
  const body = {
    entry_type: entryType,
    operation: val("q_operation"), depth: val("q_depth"),
    pump_rate: val("q_pump_rate"), sbp: val("q_sbp"), spp: val("q_spp"),
    flow_out: val("q_flow_out"), pit_volume: val("q_pit_volume"),
    equipment_status: val("q_equipment_status"), notes: val("q_notes"),
  };
  const endpoint = entryType === "tour_start" ? "/api/tour-start" : "/api/timeline";
  await api(endpoint, "POST", body);
  go("catchmeup");
}

function val(id) { return document.getElementById(id).value; }

// ---------------------------------------------------------------------
// CATCH ME UP
// ---------------------------------------------------------------------
async function renderCatchMeUp() {
  const data = await api("/api/catch-me-up");
  const last = data.last_entry;
  view.innerHTML = `
    <h1>Catch Me Up</h1>
    ${last
      ? `<p class="sub">Last update was ${data.minutes_since_last_update ?? "?"} minutes ago.</p>`
      : `<p class="sub">No updates logged yet.</p>`}

    <h2>Currently</h2>
    <div class="card">
      ${last ? entryLines(last) : `<div class="empty">Nothing logged yet. Go to Quick Update.</div>`}
    </div>

    <h2>Current Watch Items</h2>
    <div class="card">
      ${data.watch_list.length
        ? data.watch_list.map(w => `<div class="watch-item"><span>${w.text}</span><span class="timestamp">${fmtTime(w.created_at)}</span></div>`).join("")
        : `<div class="empty">No open watch items.</div>`}
    </div>

    <h2>Recent Timeline</h2>
    <div class="card">
      ${data.recent.length
        ? data.recent.map(r => timelineRow(r)).join("")
        : `<div class="empty">No entries yet.</div>`}
    </div>
  `;
}

function entryLines(e) {
  return `
    <div class="brief-line"><span class="k">Operation</span><span>${e.operation || "—"}</span></div>
    <div class="brief-line"><span class="k">Depth</span><span>${e.depth || "—"}</span></div>
    <div class="brief-line"><span class="k">Pump Rate</span><span>${e.pump_rate || "—"}</span></div>
    <div class="brief-line"><span class="k">SBP</span><span>${e.sbp || "—"}</span></div>
    <div class="brief-line"><span class="k">Flow Out</span><span>${e.flow_out || "—"}</span></div>
    <div class="brief-line"><span class="k">Pit Volume</span><span>${e.pit_volume || "—"}</span></div>
    <div class="brief-line"><span class="k">Notes</span><span>${e.notes || "—"}</span></div>
    <div class="brief-line"><span class="k">Logged</span><span class="timestamp">${fmtTime(e.ts)}</span></div>
  `;
}

function timelineRow(r) {
  return `
    <div class="watch-item">
      <div>
        <span class="pill ${r.entry_type}">${r.entry_type.replace("_", " ")}</span>
        &nbsp; ${r.operation || r.notes || "(no detail)"}
      </div>
      <span class="timestamp">${fmtTime(r.ts)}</span>
    </div>
  `;
}

// ---------------------------------------------------------------------
// WHAT CHANGED
// ---------------------------------------------------------------------
async function renderWhatChanged() {
  const [data, job] = await Promise.all([api("/api/what-changed"), api("/api/job")]);
  if (!data.ok) {
    view.innerHTML = `<h1>What Changed?</h1><div class="card empty">${data.message}</div>`;
    return;
  }
  const anyChanged = data.diff.some(d => d.changed);
  view.innerHTML = `
    <h1>What Changed?</h1>
    <p class="sub">Comparing ${fmtTime(data.previous_ts)} → ${fmtTime(data.current_ts)}</p>
    <div class="card">
      <table>
        <tr><th>Parameter</th><th>Previous</th><th>Current</th></tr>
        ${data.diff.map(d => `
          <tr class="${d.changed ? "changed" : ""}">
            <td>${d.parameter.replace("_", " ")}</td>
            <td>${d.previous || "—"}</td>
            <td class="delta">${d.current || "—"}</td>
          </tr>
        `).join("")}
      </table>
    </div>

    <h2>What to Verify</h2>
    <div class="card">
      <div class="brief-line"><span>Confirm the change on an independent measurement, not just one sensor</span></div>
      <div class="brief-line"><span>Check whether pump rate, choke position, or a connection explains it before treating it as abnormal</span></div>
      <div class="brief-line"><span>Re-check after a few minutes to see if it's a trend or a one-off reading</span></div>
    </div>

    <h2>Who Should Know</h2>
    <div class="card">${nc(job.communication_hierarchy)}</div>

    <h2>Procedure Reference</h2>
    <div class="card">${nc(job.procedure_references)}</div>

    ${anyChanged ? `<div class="actions"><button class="secondary" onclick="go('critical')">Open Critical Event Mode</button></div>` : ""}
  `;
}

// ---------------------------------------------------------------------
// SINCE LAST TOUR
// ---------------------------------------------------------------------
async function renderSinceLastTour() {
  const data = await api("/api/since-last-tour");
  if (!data.ok) {
    view.innerHTML = `<h1>Since Last Tour</h1><div class="card empty">${data.message}</div>
      <div class="actions"><button class="primary" onclick="go('quickupdate')">Mark Tour Start</button></div>`;
    return;
  }
  view.innerHTML = `
    <h1>Since Last Tour</h1>
    <h2>Tour Start</h2>
    <div class="card">${entryLines(data.tour_start)}</div>
    <h2>Events During This Tour (${data.events_during_tour.length})</h2>
    <div class="card">
      ${data.events_during_tour.length
        ? data.events_during_tour.map(r => timelineRow(r)).join("")
        : `<div class="empty">Nothing logged yet this tour.</div>`}
    </div>
    <h2>Current Status</h2>
    <div class="card">${data.current ? entryLines(data.current) : `<div class="empty">No entries yet.</div>`}</div>
  `;
}

// ---------------------------------------------------------------------
// WATCH LIST
// ---------------------------------------------------------------------
async function renderWatchList() {
  const items = await api("/api/watch-list");
  view.innerHTML = `
    <h1>Watch List</h1>
    <div class="card">
      <div class="field-row">
        <div style="grid-column: 1 / -1;">
          <label>New watch item</label>
          <input id="w_text" placeholder="e.g. Monitor SBP trend after connection">
        </div>
      </div>
      <div class="actions"><button class="primary" onclick="addWatch()">Add</button></div>
    </div>
    <div class="card">
      ${items.length ? items.map(w => `
        <div class="watch-item">
          <span style="${w.resolved ? "text-decoration:line-through;color:var(--muted);" : ""}">${w.text}</span>
          ${w.resolved
            ? `<span class="timestamp">resolved ${fmtTime(w.resolved_at)}</span>`
            : `<button class="danger" onclick="resolveWatch(${w.id})">Resolve</button>`}
        </div>
      `).join("") : `<div class="empty">No watch items yet.</div>`}
    </div>
  `;
}

async function addWatch() {
  const text = val("w_text");
  if (!text.trim()) return;
  await api("/api/watch-list", "POST", { text });
  go("watchlist");
}

async function resolveWatch(id) {
  await api(`/api/watch-list/${id}/resolve`, "GET");
  go("watchlist");
}

// ---------------------------------------------------------------------
// MEETING MODE
// ---------------------------------------------------------------------
async function renderMeeting() {
  const b = await api("/api/meeting-brief");
  const statement = `Currently ${b.operation.toLowerCase()} at ${b.depth}` +
    (b.pump_rate !== "—" ? `, pumps at ${b.pump_rate}` : "") +
    (b.sbp !== "—" ? `, SBP ${b.sbp}` : "") +
    (b.watch_items.length ? `. ${b.watch_items.length} open watch item(s).` : ". No open watch items.");
  view.innerHTML = `
    <h1>Meeting in 2 Minutes</h1>
    <div class="card">
      <div class="brief-line"><span class="k">Well</span><span>${nc(b.well_name)}</span></div>
      <div class="brief-line"><span class="k">Rig</span><span>${nc(b.rig_name)}</span></div>
      <div class="brief-line"><span class="k">Current Section</span><span>${nc(b.current_section)}</span></div>
      <div class="brief-line"><span class="k">Operation</span><span>${b.operation}</span></div>
      <div class="brief-line"><span class="k">Depth</span><span>${b.depth}</span></div>
      <div class="brief-line"><span class="k">Pump Rate</span><span>${b.pump_rate}</span></div>
      <div class="brief-line"><span class="k">SBP</span><span>${b.sbp}</span></div>
      <div class="brief-line"><span class="k">Flow Out</span><span>${b.flow_out}</span></div>
      <div class="brief-line"><span class="k">Last Note</span><span>${b.last_event_notes}</span></div>
    </div>

    <h2>Suggested Status Statement</h2>
    <div class="card">${statement}</div>

    <h2>Open Watch Items</h2>
    <div class="card">
      ${b.watch_items.length ? b.watch_items.map(w => `<div class="watch-item"><span>${w.text}</span></div>`).join("")
        : `<div class="empty">None.</div>`}
    </div>

    <h2>Questions You May Be Asked</h2>
    <div class="card">
      <div class="brief-line"><span>Current depth and section?</span></div>
      <div class="brief-line"><span>Any abnormal indications since last update?</span></div>
      <div class="brief-line"><span>Any open watch items or outstanding actions?</span></div>
      <div class="brief-line"><span>What's the plan for the next operation?</span></div>
    </div>
  `;
}

// ---------------------------------------------------------------------
// DECISION / EVENT LOG
// ---------------------------------------------------------------------
async function renderDecisionLog() {
  const rows = await api("/api/decision-log");
  view.innerHTML = `
    <h1>Decision / Event Log</h1>
    <div class="card">
      <div class="field-row wide"><div><label>Observation</label><textarea id="d_observation"></textarea></div></div>
      <div class="field-row">
        <div><label>Confirmation</label><input id="d_confirmation"></div>
        <div><label>People Notified</label><input id="d_people_notified"></div>
      </div>
      <div class="field-row">
        <div><label>Procedure Reference</label><input id="d_procedure_reference"></div>
        <div><label>Action Status</label><input id="d_action_status"></div>
      </div>
      <div class="field-row">
        <div><label>Result</label><input id="d_result"></div>
        <div><label>Outstanding Item</label><input id="d_outstanding_item"></div>
      </div>
      <div class="actions"><button class="primary" onclick="addDecision()">Log Entry</button></div>
    </div>
    <div class="card">
      ${rows.length ? rows.map(r => `
        <div style="border-bottom:1px solid var(--border); padding:10px 0;">
          <div class="timestamp">${fmtTime(r.ts)}</div>
          <div><b>${r.observation || "—"}</b></div>
          <div class="muted" style="font-size:13px;">
            Confirmed: ${r.confirmation || "—"} · Notified: ${r.people_notified || "—"} ·
            Procedure: ${r.procedure_reference || "—"} · Status: ${r.action_status || "—"} ·
            Result: ${r.result || "—"} · Outstanding: ${r.outstanding_item || "—"}
          </div>
        </div>
      `).join("") : `<div class="empty">No log entries yet.</div>`}
    </div>
  `;
}

async function addDecision() {
  const body = {
    observation: val("d_observation"), confirmation: val("d_confirmation"),
    people_notified: val("d_people_notified"), procedure_reference: val("d_procedure_reference"),
    action_status: val("d_action_status"), result: val("d_result"),
    outstanding_item: val("d_outstanding_item"),
  };
  await api("/api/decision-log", "POST", body);
  go("decisionlog");
}

// ---------------------------------------------------------------------
// FIELD PLAYBOOK — static reference content, offline
// ---------------------------------------------------------------------
const PLAYBOOK = [
  {
    name: "Drilling Ahead",
    understand: "Normal steady-state operation: pumps circulating, choke holding backpressure, bit making hole.",
    watch: "SBP trend, SPP trend, flow-in vs flow-out match, pit volume trend, ROP.",
    ask: "What is the current approved SBP/ECD window for this section?",
    communicate: "Agree with the MPD Supervisor what a 'normal' parameter range looks like right now.",
    record: "Depth, pump rate, SBP, SPP, flow, pit volume at the start of your tour and at each change.",
  },
  {
    name: "Connection",
    understand: "Pumps go off and on; the choke must take over holding bottomhole pressure while pumps are down.",
    watch: "SBP through the pump-down and pump-up transition, flow behavior right after pumps restart.",
    ask: "Is the choke in automatic or manual mode for this connection? Who is on the choke?",
    communicate: "Confirm timing with the Driller before pumps go down.",
    record: "SBP just before shutdown, during static period, and once circulation resumes.",
  },
  {
    name: "Pump Shutdown / Startup",
    understand: "Backpressure through the choke must compensate for the lost/gained circulating friction to keep BHP constant.",
    watch: "SBP response as pump rate ramps down or up, any lag or overshoot.",
    ask: "What SBP is the choke targeting through this transition?",
    communicate: "Give the choke operator advance notice of the planned rate change.",
    record: "Pump rate steps and corresponding SBP at each step.",
  },
  {
    name: "Circulation / Bottoms Up",
    understand: "Circulating a known volume to surface to clear cuttings or confirm well condition.",
    watch: "Gas readings, flow-out vs flow-in, pit volume, any losses or gains.",
    ask: "What is bottoms-up volume and expected time for this circulation?",
    communicate: "Notify Company Rep if circulating for a specific reason (e.g. after connection gas).",
    record: "Start time, volume pumped, any changes in returns.",
  },
  {
    name: "Flow Check",
    understand: "Pumps off, well shut in or choke closed, watching for flow that shouldn't be there.",
    watch: "Flow line, trip tank or pit volume, any independent flow indication.",
    ask: "What is the well supposed to do right now if everything is normal?",
    communicate: "Report result of every flow check to the Driller/Supervisor, even if negative.",
    record: "Start time, duration, observed flow or no-flow, who confirmed it.",
  },
  {
    name: "Tripping (POOH / RIH)",
    understand: "Pipe movement changes annulus volume; hole must take/give the correct displacement.",
    watch: "Trip tank volume vs. calculated displacement, swab/surge indications, drag/overpull.",
    ask: "What is the approved tripping speed and displacement tolerance for this hole size?",
    communicate: "Agree trip monitoring method (trip tank, MPD system) with the Supervisor before starting.",
    record: "Volumes in vs. out per stand, any deviation from calculated displacement.",
  },
  {
    name: "Casing / Liner Running",
    understand: "Running casing changes annulus geometry and displacement; float equipment and centralization matter.",
    watch: "Fill-up volumes, any losses while running, torque/drag.",
    ask: "What is the approved running speed and fill-up procedure?",
    communicate: "Confirm circulation plan once casing is landed before cementing.",
    record: "Fill-up volumes, any losses, final landed depth.",
  },
  {
    name: "Cementing",
    understand: "Displacing cement into place; pressure and returns behavior differ from drilling fluid.",
    watch: "Pump pressure trend, returns at surface, displacement volume vs. plan.",
    ask: "What is the planned displacement volume and expected bump pressure?",
    communicate: "Confirm plug bump and pressure test result with the Company Rep before moving on.",
    record: "Volumes pumped, pressures through the job, bump time and pressure.",
  },
  {
    name: "MPD Rig-Up & Function Test",
    understand: "Verifying RCD, choke manifold, and sensors are functional and correctly configured before relying on them.",
    watch: "Each function test result against expected response.",
    ask: "What is the approved function-test checklist for this equipment?",
    communicate: "Report any failed function test immediately — do not proceed on unverified equipment.",
    record: "Each test performed, pass/fail, who witnessed it.",
  },
  {
    name: "Abnormal Event Response",
    understand: "Something changed outside expected behavior — this is not a script, it's a trigger to slow down and think.",
    watch: "Whatever changed first, and whether it's confirmed independently.",
    ask: "Is the well pumping, flowing, or static right now? Is there an alarm?",
    communicate: "Notify per the communication hierarchy immediately, even before you have the full picture.",
    record: "Use Critical Event Mode to organize facts, and log it in the Decision/Event Log.",
  },
];

function renderPlaybook() {
  view.innerHTML = `
    <h1>Field Playbook</h1>
    <p class="sub">Offline reference. Not a substitute for approved job-specific procedures — check the Job Brain's procedure references for anything specific to this well.</p>
    ${PLAYBOOK.map(op => `
      <div class="card">
        <h1 style="font-size:16px; margin-bottom:10px;">${op.name}</h1>
        <div class="brief-line"><span class="k">Understand</span><span>${op.understand}</span></div>
        <div class="brief-line"><span class="k">Watch</span><span>${op.watch}</span></div>
        <div class="brief-line"><span class="k">Ask</span><span>${op.ask}</span></div>
        <div class="brief-line"><span class="k">Communicate</span><span>${op.communicate}</span></div>
        <div class="brief-line"><span class="k">Record</span><span>${op.record}</span></div>
      </div>
    `).join("")}
  `;
}

// ---------------------------------------------------------------------
// WHAT DO I SAY — communication templates, filled from Job Brain + status
// ---------------------------------------------------------------------
async function renderWhatDoISay() {
  const [job, cmu] = await Promise.all([api("/api/job"), api("/api/catch-me-up")]);
  const last = cmu.last_entry || {};
  const statusLine = `${last.operation || "current operation not logged"}, depth ${last.depth || "—"}, SBP ${last.sbp || "—"}, pumps ${last.pump_rate || "—"}, flow ${last.flow_out || "—"}.`;
  const watchLine = cmu.watch_list.length
    ? `Open watch items: ${cmu.watch_list.map(w => w.text).join("; ")}.`
    : "No open watch items.";

  const templates = [
    { label: "Talk to Driller", body: `Status: ${statusLine} ${watchLine}` },
    { label: "Talk to MPD Supervisor", body: `Well ${job.well_name || "—"}, ${job.current_section || "current section not set"}. ${statusLine} ${watchLine} Let me know if you want anything adjusted.` },
    { label: "Talk to Company Representative", body: `Update on ${job.well_name || "the well"}: ${statusLine} ${watchLine}` },
    { label: "Toolbox Talk Opener", body: `Today we're ${last.operation || "[operation]"} on ${job.well_name || "[well]"}. Key hazards to keep in mind for this operation are in the Field Playbook. Any questions before we start?` },
    { label: "Connection Communication", body: `Coming up on a connection. Confirming pumps down at your call, choke on ${last.sbp ? "target SBP " + last.sbp : "target SBP"}. Let me know when you're ready.` },
    { label: "Abnormal Event Notification", body: `Flagging a change: ${statusLine} This is outside what I'd expect as normal — requesting guidance before proceeding.` },
    { label: "Shift Handover", body: `Handover for ${job.well_name || "—"}: ${statusLine} ${watchLine} See Decision/Event Log for anything else from this tour.` },
  ];

  view.innerHTML = `
    <h1>What Do I Say?</h1>
    <p class="sub">Drafted from your Job Brain and latest status. Edit before you actually send or say it.</p>
    ${templates.map(t => `
      <div class="card">
        <h2 style="margin-top:0;">${t.label}</h2>
        <textarea rows="3" readonly style="cursor:text;">${t.body}</textarea>
      </div>
    `).join("")}
  `;
}

// ---------------------------------------------------------------------
// CRITICAL EVENT MODE (includes Senior Engineer Brain reasoning steps)
// ---------------------------------------------------------------------
function renderCritical() {
  view.innerHTML = `
    <h1>Critical Event Mode</h1>
    <p class="sub">Slow down. Answer only what you actually know. This does not improvise an unauthorized well-control procedure — it organizes facts and gets the right people involved.</p>

    <h2>Reasoning Steps</h2>
    <div class="card">
      <div class="brief-line"><span>1. What operation am I in?</span></div>
      <div class="brief-line"><span>2. What should normally happen?</span></div>
      <div class="brief-line"><span>3. What actually changed?</span></div>
      <div class="brief-line"><span>4. Could the measurement be wrong?</span></div>
      <div class="brief-line"><span>5. What independent evidence exists?</span></div>
      <div class="brief-line"><span>6. What information is missing?</span></div>
      <div class="brief-line"><span>7. Who needs to know?</span></div>
      <div class="brief-line"><span>8. Which approved procedure governs the response?</span></div>
    </div>

    <h2>Work It Through</h2>
    <div class="card">
      <div class="field-row wide"><div><label>What operation is underway?</label><input id="ce_operation"></div></div>
      <div class="field-row wide"><div><label>What changed first, and when?</label><input id="ce_changed"></div></div>
      <div class="field-row wide"><div><label>Is the well pumping, flowing, or static?</label><input id="ce_state"></div></div>
      <div class="field-row wide"><div><label>Which parameters changed?</label><input id="ce_parameters"></div></div>
      <div class="field-row wide"><div><label>Is the observation independently confirmed? By what?</label><input id="ce_confirmed"></div></div>
      <div class="field-row wide"><div><label>Any alarm active?</label><input id="ce_alarm"></div></div>
      <div class="field-row wide"><div><label>Who is currently managing the response?</label><input id="ce_managing"></div></div>
      <div class="field-row wide"><div><label>Which approved procedure applies?</label><input id="ce_procedure"></div></div>
      <div class="field-row wide"><div><label>Missing information</label><textarea id="ce_missing"></textarea></div></div>
      <div class="actions"><button class="primary" onclick="saveCritical()">Save to Decision / Event Log</button></div>
    </div>
  `;
}

async function saveCritical() {
  const observation = `CRITICAL EVENT — Operation: ${val("ce_operation")}. Changed: ${val("ce_changed")}. Well state: ${val("ce_state")}. Parameters: ${val("ce_parameters")}. Missing info: ${val("ce_missing")}`;
  const body = {
    observation,
    confirmation: val("ce_confirmed"),
    people_notified: val("ce_managing"),
    procedure_reference: val("ce_procedure"),
    action_status: val("ce_alarm") ? `Alarm: ${val("ce_alarm")}` : "",
    result: "",
    outstanding_item: "Follow up per applicable procedure",
  };
  await api("/api/decision-log", "POST", body);
  go("decisionlog");
}

// ---------------------------------------------------------------------
// COMPETENCY TRACKER
// ---------------------------------------------------------------------
async function renderCompetency() {
  const rows = await api("/api/competency");
  view.innerHTML = `
    <h1>Competency Tracker</h1>
    <p class="sub">Keeps you honest about the difference between studying a topic and actually doing it in the field.</p>
    <div class="card">
      <div class="field-row">
        <div><label>Topic</label><input id="cp_topic" placeholder="e.g. Choke changeover"></div>
        <div><label>Confidence</label>
          <select id="cp_confidence">
            <option>Low</option><option>Medium</option><option>High</option>
          </select>
        </div>
      </div>
      <div class="field-row wide"><div><label>Notes</label><textarea id="cp_notes" placeholder="Studied it / simulated it / did it live, and when"></textarea></div></div>
      <div class="actions"><button class="primary" onclick="saveCompetency()">Save</button></div>
    </div>
    <div class="card">
      ${rows.length ? rows.map(r => `
        <div style="border-bottom:1px solid var(--border); padding:10px 0;">
          <div style="display:flex; justify-content:space-between;">
            <b>${r.topic}</b>
            <span class="pill ${r.confidence === "High" ? "update" : r.confidence === "Medium" ? "tour_start" : "event"}">${r.confidence || "—"}</span>
          </div>
          <div class="muted" style="font-size:13px;">${r.notes || ""}</div>
          <div class="timestamp">${fmtTime(r.updated_at)}</div>
        </div>
      `).join("") : `<div class="empty">No topics tracked yet.</div>`}
    </div>
  `;
}

async function saveCompetency() {
  const topic = val("cp_topic");
  if (!topic.trim()) return;
  await api("/api/competency", "POST", {
    topic, confidence: val("cp_confidence"), notes: val("cp_notes"),
  });
  go("competency");
}

// ---------------------------------------------------------------------
// CALCULATORS
// ---------------------------------------------------------------------
function renderCalculators() {
  view.innerHTML = `
    <h1>Calculators</h1>
    <p class="sub">Every result shows the formula and inputs used — nothing is a black box.</p>

    <h2>Hydrostatic Pressure</h2>
    <div class="card">
      <div class="field-row">
        <div><label>Mud Weight (ppg)</label><input id="c1_mw"></div>
        <div><label>TVD (ft)</label><input id="c1_tvd"></div>
      </div>
      <div class="actions"><button class="primary" onclick="calcHydrostatic()">Calculate</button></div>
      <div id="c1_result"></div>
    </div>

    <h2>Equivalent Mud Weight (EMW)</h2>
    <div class="card">
      <div class="field-row">
        <div><label>Pressure (psi)</label><input id="c2_p"></div>
        <div><label>TVD (ft)</label><input id="c2_tvd"></div>
      </div>
      <div class="actions"><button class="primary" onclick="calcEmw()">Calculate</button></div>
      <div id="c2_result"></div>
    </div>

    <h2>Pressure Gradient</h2>
    <div class="card">
      <div class="field-row"><div><label>Mud Weight (ppg)</label><input id="c3_mw"></div></div>
      <div class="actions"><button class="primary" onclick="calcGradient()">Calculate</button></div>
      <div id="c3_result"></div>
    </div>

    <h2>Annular Capacity</h2>
    <div class="card">
      <div class="field-row">
        <div><label>Hole ID (in)</label><input id="c4_hole"></div>
        <div><label>Pipe OD (in)</label><input id="c4_pipe"></div>
      </div>
      <div class="actions"><button class="primary" onclick="calcAnnularCapacity()">Calculate</button></div>
      <div id="c4_result"></div>
    </div>

    <h2>Pipe Capacity</h2>
    <div class="card">
      <div class="field-row"><div><label>Pipe ID (in)</label><input id="c5_id"></div></div>
      <div class="actions"><button class="primary" onclick="calcPipeCapacity()">Calculate</button></div>
      <div id="c5_result"></div>
    </div>

    <h2>Annular Velocity</h2>
    <div class="card">
      <div class="field-row">
        <div><label>Flow Rate (gpm)</label><input id="c6_q"></div>
        <div><label>Hole ID (in)</label><input id="c6_hole"></div>
      </div>
      <div class="field-row"><div><label>Pipe OD (in)</label><input id="c6_pipe"></div></div>
      <div class="actions"><button class="primary" onclick="calcAnnularVelocity()">Calculate</button></div>
      <div id="c6_result"></div>
    </div>

    <h2>Lag Time / Lag Volume</h2>
    <div class="card">
      <div class="field-row">
        <div><label>Annular Capacity (bbl/ft)</label><input id="c7_cap" placeholder="from Annular Capacity above"></div>
        <div><label>Length (ft)</label><input id="c7_len"></div>
      </div>
      <div class="field-row"><div><label>Flow Rate (bbl/min)</label><input id="c7_rate"></div></div>
      <div class="actions"><button class="primary" onclick="calcLag()">Calculate</button></div>
      <div id="c7_result"></div>
    </div>

    <h2>Unit Conversions</h2>
    <div class="card">
      <div class="field-row">
        <div><label>Conversion</label>
          <select id="c8_kind">
            <option value="ppg_to_sg">ppg → SG</option>
            <option value="sg_to_ppg">SG → ppg</option>
            <option value="bbl_to_gal">bbl → gal</option>
            <option value="gal_to_bbl">gal → bbl</option>
            <option value="ft_to_m">ft → m</option>
            <option value="m_to_ft">m → ft</option>
          </select>
        </div>
        <div><label>Value</label><input id="c8_value"></div>
      </div>
      <div class="actions"><button class="primary" onclick="calcUnitConvert()">Convert</button></div>
      <div id="c8_result"></div>
    </div>
  `;
}

function showCalcResult(elId, r, answerLabel, answerKey, unit) {
  document.getElementById(elId).innerHTML = r.ok
    ? `<div class="calc-result"><b>${r.formula}</b><br>${answerLabel}: <b>${r[answerKey]} ${unit || ""}</b></div>`
    : `<div class="calc-result">${r.message}</div>`;
}

async function calcHydrostatic() {
  const r = await api("/api/calc/hydrostatic", "POST", { mud_weight_ppg: val("c1_mw"), tvd_ft: val("c1_tvd") });
  showCalcResult("c1_result", r, "Answer", "answer_psi", "psi");
}
async function calcEmw() {
  const r = await api("/api/calc/emw", "POST", { pressure_psi: val("c2_p"), tvd_ft: val("c2_tvd") });
  showCalcResult("c2_result", r, "Answer", "answer_ppg", "ppg");
}
async function calcGradient() {
  const r = await api("/api/calc/gradient", "POST", { mud_weight_ppg: val("c3_mw") });
  showCalcResult("c3_result", r, "Answer", "answer_psi_per_ft", "psi/ft");
}
async function calcAnnularCapacity() {
  const r = await api("/api/calc/annular-capacity", "POST", { hole_id_in: val("c4_hole"), pipe_od_in: val("c4_pipe") });
  showCalcResult("c4_result", r, "Answer", "answer_bbl_per_ft", "bbl/ft");
  if (r.ok) document.getElementById("c7_cap").value = r.answer_bbl_per_ft;
}
async function calcPipeCapacity() {
  const r = await api("/api/calc/pipe-capacity", "POST", { pipe_id_in: val("c5_id") });
  showCalcResult("c5_result", r, "Answer", "answer_bbl_per_ft", "bbl/ft");
}
async function calcAnnularVelocity() {
  const r = await api("/api/calc/annular-velocity", "POST", { flow_rate_gpm: val("c6_q"), hole_id_in: val("c6_hole"), pipe_od_in: val("c6_pipe") });
  showCalcResult("c6_result", r, "Answer", "answer_ft_per_min", "ft/min");
}
async function calcLag() {
  const r = await api("/api/calc/lag", "POST", {
    annular_capacity_bbl_per_ft: val("c7_cap"), length_ft: val("c7_len"), flow_rate_bbl_per_min: val("c7_rate"),
  });
  document.getElementById("c7_result").innerHTML = r.ok
    ? `<div class="calc-result"><b>${r.formula}</b><br>Lag Volume: <b>${r.answer_lag_volume_bbl} bbl</b><br>Lag Time: <b>${r.answer_lag_time_min} min</b></div>`
    : `<div class="calc-result">${r.message}</div>`;
}
async function calcUnitConvert() {
  const r = await api("/api/calc/unit-convert", "POST", { kind: val("c8_kind"), value: val("c8_value") });
  document.getElementById("c8_result").innerHTML = r.ok
    ? `<div class="calc-result"><b>${r.formula}</b><br>Answer: <b>${r.answer} ${r.unit}</b></div>`
    : `<div class="calc-result">${r.message}</div>`;
}

// ---------------------------------------------------------------------
async function renderPreTour(){ const d=await api("/api/pre-tour-checklist"); view.innerHTML=`<h1>Pre-Tour Checklist</h1><div class="card">${d.map(x=>`<p><button onclick="toggleCheck(${x.id})">${x.done?'✓':'○'}</button> ${x.item}</p>`).join('')}</div>`; }
async function toggleCheck(id){ await api('/api/pre-tour-checklist/'+id+'/toggle'); go('pretour'); }
async function renderBarriers(){ const d=await api('/api/barriers'); view.innerHTML=`<h1>Barrier Status</h1><div class="card"><div class="field-row"><div><label>Name</label><input id="b_name"></div><div><label>Role</label><input id="b_role" placeholder="Primary / Secondary"></div></div><div class="field-row"><div><label>Status</label><input id="b_status" placeholder="Verified / Unknown"></div><div><label>Verified by</label><input id="b_by"></div></div><label>Notes</label><textarea id="b_notes"></textarea><button class="primary" onclick="saveBarrier()">Save Barrier</button></div><div class="card">${d.length?d.map(x=>`<p><b>${x.name}</b> — ${x.role||'—'} — ${x.status||'UNKNOWN'}<br><small>${x.verified_by||''} ${x.notes||''}</small></p>`).join(''):'<p>No barriers recorded.</p>'}</div>`; }
async function saveBarrier(){ await api('/api/barriers','POST',{name:val('b_name'),role:val('b_role'),status:val('b_status'),verified_by:val('b_by'),notes:val('b_notes')}); go('barriers'); }
async function renderHandover(){ const d=await api('/api/handover'); const x=d.latest||{}; view.innerHTML=`<h1>Shift Handover</h1><div class="card"><h2>Current Status</h2><p><b>Operation:</b> ${x.operation||'Not recorded'}<br><b>Depth:</b> ${x.depth||'—'}<br><b>SBP:</b> ${x.sbp||'—'}<br><b>SPP:</b> ${x.spp||'—'}<br><b>Flow-out:</b> ${x.flow_out||'—'}<br><b>Notes:</b> ${x.notes||'—'}</p><h2>Open Watch Items</h2><p>${d.watch_items.length?d.watch_items.map(esc).join('<br>'):'None recorded'}</p><h2>Barrier Status</h2><p>${d.barriers.length?d.barriers.map(b=>`${b.name}: ${b.status||'UNKNOWN'}`).join('<br>'):'Not recorded'}</p></div>`; }
const GLOSSARY={SBP:'Surface Backpressure: pressure intentionally applied at surface as part of the approved MPD operation.',BHP:'Bottomhole Pressure: pressure at the bottom of the well, interpreted within the approved well model.',ECD:'Equivalent Circulating Density: density-equivalent representation of circulating pressure effects.',EMW:'Equivalent Mud Weight: pressure expressed as an equivalent mud density.',RCD:'Rotating Control Device used to help provide a closed, controlled returns path in applicable operations.',MPD:'Managed Pressure Drilling: adaptive pressure management within the approved operating envelope.',Influx:'Unwanted formation fluid entering the well; confirmation and response follow the approved procedure.',Ballooning:'Wellbore breathing concept involving fluid exchange with the formation; do not diagnose from one signal alone.',Packoff:'Restriction to annular flow, often requiring careful verification and approved response.',POOH:'Pull Out Of Hole.',RIH:'Run In Hole.'};
function renderGlossary(){ view.innerHTML=`<h1>Glossary</h1><div class="card"><input id="gq" placeholder="Search term" oninput="filterGlossary()"><div id="glist"></div></div>`; filterGlossary(); }
function filterGlossary(){ const q=(document.getElementById('gq')?.value||'').toLowerCase(); document.getElementById('glist').innerHTML=Object.entries(GLOSSARY).filter(([k,v])=>(k+v).toLowerCase().includes(q)).map(([k,v])=>`<p><b>${k}</b><br>${v}</p>`).join(''); }
go("home");
