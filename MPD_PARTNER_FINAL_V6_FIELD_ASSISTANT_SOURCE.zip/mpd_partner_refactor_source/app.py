#!/usr/bin/env python3
import json, sqlite3, http.server, urllib.parse
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR=Path(__file__).resolve().parent
DB_PATH=BASE_DIR/'mpd_partner.db'
STATIC_DIR=BASE_DIR/'static'
PORT=8765
OPS=['Drilling ahead','Connection','Flow check','Static condition','Tripping','POOH','RIH','Reaming','Backreaming','Wiper trip','Casing','Cementing','Liner operations','Pressure test','BOP operation','MPD commissioning','Equipment testing','Shutdown','Abnormal event']
FIELDS=['depth','mud_weight','pump_rate','sbp','spp','flow_out','pit_volume']
UNITS={'depth':'ft','mud_weight':'ppg','pump_rate':'gpm','sbp':'psi','spp':'psi','flow_out':'gpm','pit_volume':'bbl'}

def now_iso(): return datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')
def db():
 c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def init_db():
 c=db(); c.executescript('''
 CREATE TABLE IF NOT EXISTS job_config (id INTEGER PRIMARY KEY CHECK(id=1),rig_name TEXT,rig_type TEXT,operator TEXT,well_name TEXT,location TEXT,current_section TEXT,mud_system TEXT,procedure_references TEXT,approved_operating_limits TEXT,updated_at TEXT);
 CREATE TABLE IF NOT EXISTS timeline (id INTEGER PRIMARY KEY AUTOINCREMENT,ts TEXT NOT NULL,operation TEXT,depth TEXT,mud_weight TEXT,pump_rate TEXT,sbp TEXT,spp TEXT,flow_out TEXT,pit_volume TEXT,flow_status TEXT,pit_status TEXT,equipment_status TEXT,concern TEXT,notes TEXT,source TEXT DEFAULT 'manual');
 CREATE TABLE IF NOT EXISTS watch_list (id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL,text TEXT NOT NULL,resolved INTEGER DEFAULT 0,resolved_at TEXT);
 CREATE TABLE IF NOT EXISTS barriers (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,role TEXT,status TEXT,verified_by TEXT,notes TEXT,updated_at TEXT);
 CREATE TABLE IF NOT EXISTS assistant_state (id INTEGER PRIMARY KEY CHECK(id=1),current_operation TEXT,status TEXT,updated_at TEXT);
 ''')
 # migration from older APK schema
 cols={r[1] for r in c.execute('PRAGMA table_info(timeline)').fetchall()}
 for name in ['mud_weight','flow_status','pit_status','concern','source']:
  if name not in cols: c.execute(f'ALTER TABLE timeline ADD COLUMN {name} TEXT')
 c.commit(); c.close()

def rows(q,args=()):
 c=db(); out=[dict(r) for r in c.execute(q,args).fetchall()]; c.close(); return out

def one(q,args=()):
 c=db(); r=c.execute(q,args).fetchone(); c.close(); return dict(r) if r else {}

def num(v):
 try: return float(str(v).replace(',','').strip())
 except: return None

def latest(): return one('SELECT * FROM timeline ORDER BY id DESC LIMIT 1')
def latest_rows(n=100): return rows('SELECT * FROM timeline ORDER BY id DESC LIMIT ?',(n,))
def state(): return one('SELECT * FROM assistant_state WHERE id=1')

def save_update(b):
 c=db(); last=latest(); op=b.get('operation') or last.get('operation','')
 vals={k:(b.get(k) if b.get(k) not in (None,'') else last.get(k,'')) for k in FIELDS}
 c.execute('''INSERT INTO timeline(ts,operation,depth,mud_weight,pump_rate,sbp,spp,flow_out,pit_volume,flow_status,pit_status,equipment_status,concern,notes,source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(now_iso(),op,vals['depth'],vals['mud_weight'],vals['pump_rate'],vals['sbp'],vals['spp'],vals['flow_out'],vals['pit_volume'],b.get('flow_status','') or last.get('flow_status',''),b.get('pit_status','') or last.get('pit_status',''),b.get('equipment_status','') or last.get('equipment_status',''),b.get('concern','') or last.get('concern',''),b.get('notes',''),b.get('source','manual')))
 c.execute('INSERT INTO assistant_state(id,current_operation,status,updated_at) VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET current_operation=excluded.current_operation,status=excluded.status,updated_at=excluded.updated_at',(op,b.get('status','') or state().get('status','Unknown'),now_iso()))
 c.commit(); c.close(); return {'ok':True,'latest':latest()}

def trend(field,n=30):
 rs=list(reversed(latest_rows(n))); vals=[(r,num(r.get(field))) for r in rs if num(r.get(field)) is not None]
 if len(vals)<2:return {'direction':'insufficient data','delta':None,'count':len(vals)}
 a,b=vals[0][1],vals[-1][1]; d=b-a; eps=max(abs(a)*0.002,0.01)
 return {'direction':'increasing' if d>eps else 'decreasing' if d<-eps else 'stable','delta':round(d,3),'count':len(vals),'first':a,'last':b}

def fingerprint():
 rs=list(reversed(latest_rows(100))); recent=rs[-8:]; best=None
 # compare recent normalized SBP/flow/pit shape with earlier windows
 def vec(win):
  out=[]
  for f in ['sbp','flow_out','pit_volume']:
   a=[num(x.get(f)) for x in win]; a=[x for x in a if x is not None]
   if len(a)>=2:
    base=a[0] or 1; out += [round((x-base)/max(abs(base),1),3) for x in a[-4:]]
  return out
 rv=vec(recent)
 if len(rv)>=3:
  for i in range(0,max(0,len(rs)-16)):
   w=rs[i:i+8]; hv=vec(w)
   if len(hv)==len(rv):
    score=sum((a-b)**2 for a,b in zip(rv,hv))/len(rv)
    if best is None or score<best[0]: best=(score,w)
 return {'recent_points':len(recent),'similarity': round(100/(1+(best[0]*100)) if best else 0,1),'similar_window':best[1] if best and best[0]<0.05 else [],'note':'Pattern comparison uses your recorded data only. It is not a diagnostic classification.'}

def situation():
 l=latest(); s=state(); watch=rows('SELECT * FROM watch_list WHERE resolved=0 ORDER BY id DESC')
 return {'latest':l,'state':s,'watch_items':watch,'trends':{f:trend(f) for f in FIELDS},'fingerprint':fingerprint()}

def handover():
 sit=situation(); recent=list(reversed(latest_rows(12))); l=sit['latest']
 changes=[]
 for f in ['sbp','spp','flow_out','pit_volume','pump_rate']:
  t=sit['trends'][f]
  if t['direction'] not in ('stable','insufficient data'): changes.append(f"{f.replace('_',' ').upper()} {t['direction']} ({t['delta']:+})")
 return {'latest':l,'current':sit['state'],'recent':recent,'changes':changes,'watch_items':sit['watch_items'],'barriers':rows('SELECT * FROM barriers ORDER BY id DESC LIMIT 20'),'generated_summary':f"Current operation: {l.get('operation') or 'not recorded'}. Latest confirmed update: {l.get('notes') or 'no narrative note'}. Follow up on {len(sit['watch_items'])} open watch item(s)."}

def prejob(operation=None):
 sit=situation(); l=sit['latest']; op=operation or l.get('operation') or sit['state'].get('current_operation') or 'Select operation'
 base={
 'what_to_say':[f'We are preparing for: {op}.','Confirm the current condition using confirmed readings and the approved job procedure.','Confirm roles, communication path and who calls out deviations.','Review what will be monitored, expected response and when to stop and reassess under the approved procedure.'],
 'questions':['What is the exact planned sequence?','Who owns each communication and confirmation?','Which readings and equipment indications are being monitored?','What changed since the last stable condition?','What is the approved escalation path for a deviation?'],
 'monitor':['Confirmed pressure and flow readings','Pit trend and data quality','Equipment status','Open watch items','Barrier / procedure status'],
 'closing':'Before starting, confirm everyone understands the plan, communication, monitoring responsibilities and the approved response to deviations.'}
 if op in ('Connection','Drilling ahead','Reaming','Backreaming'): base['what_to_say'].append('Confirm the expected pressure/flow response for the operation from the approved procedure; do not rely on generic limits.')
 if op in ('Tripping','POOH','RIH','Wiper trip'): base['what_to_say'].append('Confirm the trip plan, monitoring responsibilities and communication points before proceeding.')
 return {'operation':op,'latest':l,'watch_items':sit['watch_items'],**base}

def assistant(q):
 q=(q or '').lower(); sit=situation(); l=sit['latest']; op=l.get('operation') or sit['state'].get('current_operation') or 'not set'; t=sit['trends'];
 ans={'what_i_understand':f"Your current saved operation is {op}. The latest note is: {l.get('notes') or 'none recorded'}. I am using confirmed local data only.", 'what_changed':[], 'what_to_check':[], 'questions_to_ask':[], 'what_to_communicate':'', 'what_to_record':'Record time, operation, confirmed values, observations, communication and outcome.', 'safety_note':'This assistant supports awareness, pattern review and communication. It does not diagnose a kick, ballooning or losses, and does not replace the trained crew or approved procedure.'}
 ans['what_changed']=[f"{f.replace('_',' ')}: {x['direction']}" for f,x in t.items() if x['direction'] not in ('stable','insufficient data')]
 ans['what_to_check']=['Confirm the latest readings against the approved job data and procedure.','Check sensor/data quality before interpreting a trend.',f"Review {len(sit['watch_items'])} open watch item(s) and current equipment/barrier information."]
 ans['questions_to_ask']=['What changed immediately before this condition?','Are independent measurements consistent?','What does the approved procedure require now?']
 if any(k in q for k in ['driller','say','meeting','pre-job']):
  p=prejob(); ans['what_to_communicate']=' '.join(p['what_to_say'])
 elif 'handover' in q: ans['what_to_communicate']=handover()['generated_summary']
 elif 'catch' in q or 'what happened' in q: ans['what_to_communicate']=f"Current operation: {op}. Latest note: {l.get('notes') or 'none'}. " + ('; '.join(ans['what_changed']) if ans['what_changed'] else 'No clear numeric change can be established yet.')
 else: ans['what_to_communicate']=f"State the confirmed observation, current operation ({op}), what is being monitored and any open concern. Keep assumptions separate from confirmed facts."
 return ans

def sample_data():
 c=db(); c.execute('DELETE FROM timeline'); c.execute('DELETE FROM watch_list'); c.execute('DELETE FROM barriers');
 ops=['Drilling ahead','Connection','Drilling ahead','Reaming']; depth=12400; sbp=420; spp=2350; flow=650; pit=0.0
 for i in range(100):
  phase=ops[(i//18)%len(ops)]; depth += 2 if phase=='Drilling ahead' else 0
  if phase=='Connection': flow=20; sbp=390
  else: flow=650+(i%5)*3; sbp=420+(i%7-3)*4
  spp=2350+(i%9-4)*12; pit=(i%11-5)*0.08
  ts=datetime.now(timezone.utc).astimezone().replace(microsecond=0).isoformat()
  note=['Stable drilling update','Connection completed; values confirmed','Monitoring response after operational change','Routine confirmed reading'][i%4]
  c.execute('INSERT INTO timeline(ts,operation,depth,mud_weight,pump_rate,sbp,spp,flow_out,pit_volume,flow_status,pit_status,equipment_status,concern,notes,source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(ts,phase,str(depth),'11.8',str(flow),str(sbp),str(spp),str(flow),str(round(pit,2)),'Normal','Stable','Normal','Monitor' if i%23==0 else '',note,'sample'))
 c.execute('INSERT INTO watch_list(created_at,text,resolved) VALUES(?,?,0)',(now_iso(),'Confirm current sensor agreement before next planned operation.'))
 c.execute('INSERT INTO watch_list(created_at,text,resolved) VALUES(?,?,0)',(now_iso(),'Review latest approved procedure reference before the next critical operation.'))
 c.execute('INSERT INTO assistant_state(id,current_operation,status,updated_at) VALUES(1,?,?,?) ON CONFLICT(id) DO UPDATE SET current_operation=excluded.current_operation,status=excluded.status,updated_at=excluded.updated_at',('Drilling ahead','Monitoring',now_iso()))
 c.commit(); c.close(); return {'ok':True,'count':100}

def clear_all():
 c=db();
 for t in ['job_config','timeline','watch_list','barriers','assistant_state']: c.execute('DELETE FROM '+t)
 c.commit(); c.close(); return {'ok':True}

def get_job(): return one('SELECT * FROM job_config WHERE id=1')
def save_job(b):
 fields=['rig_name','rig_type','operator','well_name','location','current_section','mud_system','procedure_references','approved_operating_limits']; vals=[b.get(f,'') for f in fields]
 c=db(); c.execute('INSERT INTO job_config(id,'+','.join(fields)+',updated_at) VALUES(1,'+','.join('?'*len(fields))+',?) ON CONFLICT(id) DO UPDATE SET '+','.join(f+'=excluded.'+f for f in fields)+',updated_at=excluded.updated_at',vals+[now_iso()]); c.commit(); c.close(); return get_job()

def get_watch(): return rows('SELECT * FROM watch_list ORDER BY resolved,id DESC')
def add_watch(b):
 c=db(); c.execute('INSERT INTO watch_list(created_at,text,resolved) VALUES(?,?,0)',(now_iso(),b.get('text',''))); c.commit(); c.close(); return {'ok':True}
def resolve_watch(i):
 c=db(); c.execute('UPDATE watch_list SET resolved=1,resolved_at=? WHERE id=?',(now_iso(),i)); c.commit(); c.close(); return {'ok':True}

def get_barriers(): return rows('SELECT * FROM barriers ORDER BY id DESC')
def save_barrier(b):
 c=db(); c.execute('INSERT INTO barriers(name,role,status,verified_by,notes,updated_at) VALUES(?,?,?,?,?,?)',(b.get('name',''),b.get('role',''),b.get('status',''),b.get('verified_by',''),b.get('notes',''),now_iso())); c.commit(); c.close(); return {'ok':True}

def calc_hydro(b):
 try: mw=float(b['mud_weight_ppg']); tvd=float(b['tvd_ft']); return {'ok':True,'formula':'P (psi) = 0.052 × MW (ppg) × TVD (ft)','answer_psi':round(.052*mw*tvd,1)}
 except:return {'ok':False,'message':'Enter MW and TVD as numbers.'}
def calc_emw(b):
 try:
  p=float(b['pressure_psi']); tvd=float(b['tvd_ft']); return {'ok':True,'formula':'EMW = Pressure / (0.052 × TVD)','answer_ppg':round(p/(.052*tvd),2)} if tvd else {'ok':False,'message':'TVD cannot be zero.'}
 except:return {'ok':False,'message':'Enter pressure and TVD as numbers.'}

GET={'/api/job':lambda c:get_job(),'/api/latest':lambda c:latest(),'/api/situation':lambda c:situation(),'/api/trends':lambda c:{'rows':list(reversed(latest_rows(100))),'trends':{f:trend(f,100) for f in FIELDS},'units':UNITS},'/api/fingerprint':lambda c:fingerprint(),'/api/handover':lambda c:handover(),'/api/prejob':lambda c:prejob(),'/api/watch-list':lambda c:get_watch(),'/api/barriers':lambda c:get_barriers(),'/api/operations':lambda c:OPS,'/api/timeline':lambda c:list(reversed(latest_rows(100)))}
POST={'/api/update':lambda c,b:save_update(b),'/api/ask-partner':lambda c,b:assistant(b.get('query','')),'/api/sample-data':lambda c,b:sample_data(),'/api/clear-all':lambda c,b:clear_all(),'/api/job':lambda c,b:save_job(b),'/api/watch-list':lambda c,b:add_watch(b),'/api/barriers':lambda c,b:save_barrier(b),'/api/calc/hydrostatic':lambda c,b:calc_hydro(b),'/api/calc/emw':lambda c,b:calc_emw(b)}

class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw): super().__init__(*a,directory=str(STATIC_DIR),**kw)
 def sendj(self,o,code=200):
  x=json.dumps(o).encode(); self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(x))); self.end_headers(); self.wfile.write(x)
 def do_GET(self):
  p=urllib.parse.urlparse(self.path); path=p.path
  if path.startswith('/api/watch-list/') and path.endswith('/resolve'):
   return self.sendj(resolve_watch(int(path.split('/')[-2])))
  if path=='/api/prejob':
   try:return self.sendj(prejob(urllib.parse.parse_qs(p.query).get('operation',[''])[0] or None))
   except Exception as e:return self.sendj({'ok':False,'message':str(e)},500)
  if path in GET:
   try:return self.sendj(GET[path](None))
   except Exception as e:return self.sendj({'ok':False,'message':str(e)},500)
  return super().do_GET()
 def do_POST(self):
  p=urllib.parse.urlparse(self.path).path
  try: body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0')) or 0) or b'{}')
  except: body={}
  if p in POST:
   try:return self.sendj(POST[p](None,body))
   except Exception as e:return self.sendj({'ok':False,'message':str(e)},500)
  self.sendj({'ok':False,'message':'Not found'},404)
 def log_message(self,*a): pass

def main():
 init_db();
 with http.server.ThreadingHTTPServer(('127.0.0.1',PORT),Handler) as s: s.serve_forever()
if __name__=='__main__': main()
