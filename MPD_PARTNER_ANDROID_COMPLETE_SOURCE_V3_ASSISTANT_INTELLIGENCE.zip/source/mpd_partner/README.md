# MPD PARTNER

Your personal MPD Wellsite Engineer field companion. Runs entirely on
your own laptop. No internet connection, accounts, or API keys needed.
Nothing you enter leaves this machine.

## Requirements

Python 3.8 or newer. Nothing else — no pip installs.

## Run it

```
cd mpd_partner
python3 app.py
```

Then open **http://localhost:8765** in your browser.

Leave the terminal window open while you use it. Press `Ctrl+C` in
that terminal to stop the server.

Your data lives in `mpd_partner.db` (SQLite) right next to `app.py`.
Back that file up if you want to keep history across laptops — just
copy it over.

## What's built

- **Job Brain** — rig/well/job configuration, set up once. Blank
  fields show "NOT CONFIGURED — VERIFY APPROVED JOB DOCUMENTATION"
  instead of guessing.
- **Quick Update** — fast structured entry (operation, depth, pump
  rate, SBP, SPP, flow, pit volume, equipment, notes), logged as an
  update, an event, or a tour start marker.
- **Catch Me Up** — current status, minutes since last update, open
  watch items, recent timeline.
- **What Changed?** — table comparing your last two logged entries,
  plus what to verify, who should know (from Job Brain), and the
  procedure reference (from Job Brain).
- **Since Last Tour** — everything logged since you last marked
  "Tour Start."
- **Watch List** — add and resolve persistent items to keep an eye on.
- **Meeting in 2 Minutes** — status briefing, a suggested one-line
  status statement, and likely questions.
- **Decision / Event Log** — timestamped record: observation,
  confirmation, people notified, procedure reference, action status,
  result, outstanding item.
- **Critical Event Mode** — the 8-question structured reasoning
  framework (this also covers what the original design called
  "Senior Engineer Brain" and "I Don't Know What Is Happening" — same
  underlying questions). Saves straight into the Decision/Event Log.
- **Field Playbook** — offline reference covering 10 core operations
  (drilling ahead, connections, pump shutdown/startup, circulation,
  flow checks, tripping, casing/liner running, cementing, MPD
  rig-up/function test, abnormal event response), each with
  Understand / Watch / Ask / Communicate / Record.
- **What Do I Say?** — communication templates for Driller, MPD
  Supervisor, Company Rep, toolbox talk, connections, abnormal
  events, and handover — auto-filled from Job Brain and your latest
  status.
- **Competency Tracker** — topic, confidence level, notes.
- **Calculators** — hydrostatic pressure, EMW, pressure gradient,
  annular capacity, pipe capacity, annular velocity, lag time/volume,
  and unit conversions (ppg↔SG, bbl↔gal, ft↔m). Every result shows
  the formula and inputs used.

## Deliberately not built

- **Document Brain** (uploading/searching approved procedures) —
  just keep the PDF open in another tab; not worth the complexity
  for personal use.
- **Equipment/Visual Brain** (rig diagrams and photos) — becomes a
  content project of its own.
- **Teach Me From This / Formula of the Moment as a dynamic feature**
  — these need an LLM to generate lessons on the fly, which breaks
  offline-first. The formulas themselves are all in Calculators.
- **AI Brain (online reasoning layer)** — this was always the
  "nice to have when online" layer, not core to the offline tool.
- **Voice input** — you said you'll type, so this was skipped.

## Moving to mobile later

The backend (`app.py`) is a plain JSON API over SQLite — no framework
lock-in. When you're ready for a phone version, the same API can sit
behind a small React Native or Flutter app, or you can just make this
page installable as a PWA and run the server on a small always-on
device (or your phone itself, if you go with something like Termux).
Nothing in the data model needs to change for that move.
