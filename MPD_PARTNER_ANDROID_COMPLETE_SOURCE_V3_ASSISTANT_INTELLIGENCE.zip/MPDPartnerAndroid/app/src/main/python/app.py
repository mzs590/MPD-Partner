import os
import threading
#!/usr/bin/env python3
"""
MPD PARTNER — Personal MPD Wellsite Engineer Field Companion
Runs entirely locally. No internet required. No dependencies beyond
the Python standard library.

Start it with:  python3 app.py
Then open:       http://localhost:8765

All data lives in mpd_partner.db (SQLite) next to this file. Nothing
leaves your laptop.
"""

import json
import sqlite3
import http.server
import socketserver
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "mpd_partner.db"
STATIC_DIR = BASE_DIR / "static"
PORT = 8765

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    conn.executescript(
        """
        -- JOB BRAIN: one row, set up once per job. Only ever overwritten,
        -- never silently invented. Empty fields must render as
        -- "NOT CONFIGURED — VERIFY APPROVED JOB DOCUMENTATION" in the UI,
        -- not be filled with a guess.
        CREATE TABLE IF NOT EXISTS job_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            rig_name TEXT,
            rig_type TEXT,
            operator TEXT,
            well_name TEXT,
            location TEXT,
            hole_sections TEXT,
            casing_program TEXT,
            current_section TEXT,
            mud_system TEXT,
            current_mud_weight TEXT,
            units TEXT,
            mpd_config TEXT,
            rcd_config TEXT,
            choke_arrangement TEXT,
            sensor_locations TEXT,
            flow_measurement_locations TEXT,
            pressure_measurement_locations TEXT,
            gas_handling_arrangement TEXT,
            key_personnel TEXT,
            communication_hierarchy TEXT,
            approved_operating_limits TEXT,
            procedure_references TEXT,
            updated_at TEXT
        );

        -- SHIFT BRAIN: timeline of every quick update / event / tour start.
        CREATE TABLE IF NOT EXISTS timeline (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            entry_type TEXT NOT NULL,       -- 'update' | 'event' | 'tour_start'
            operation TEXT,
            depth TEXT,
            pump_rate TEXT,
            sbp TEXT,
            spp TEXT,
            flow_out TEXT,
            pit_volume TEXT,
            equipment_status TEXT,
            notes TEXT
        );

        CREATE TABLE IF NOT EXISTS watch_list (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            text TEXT NOT NULL,
            resolved INTEGER NOT NULL DEFAULT 0,
            resolved_at TEXT
        );

        CREATE TABLE IF NOT EXISTS decision_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            observation TEXT,
            confirmation TEXT,
            people_notified TEXT,
            procedure_reference TEXT,
            action_status TEXT,
            result TEXT,
            outstanding_item TEXT
        );

        -- PERSONAL COMPETENCY TRACKER
        CREATE TABLE IF NOT EXISTS competency (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic TEXT NOT NULL UNIQUE,
            confidence TEXT,
            notes TEXT,
            updated_at TEXT
        );

        CREATE TABLE IF NOT EXISTS assistant_state (
            id INTEGER PRIMARY KEY CHECK (id=1),
            current_operation TEXT, status TEXT, trend TEXT, flow_status TEXT, pit_status TEXT,
            equipment_status TEXT, concern TEXT, mud_weight TEXT, notes TEXT, updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, happened TEXT, confusing TEXT, lesson TEXT, remember TEXT
        );
        CREATE TABLE IF NOT EXISTS barriers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, role TEXT, status TEXT, verified_at TEXT, verified_by TEXT, notes TEXT, updated_at TEXT
        );
        CREATE TABLE IF NOT EXISTS pre_tour_checklist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item TEXT NOT NULL UNIQUE, done INTEGER NOT NULL DEFAULT 0, updated_at TEXT
        );
        """
    )
    defaults = ["Current operation understood", "Previous handover reviewed", "Current parameters checked", "Watch items reviewed", "Equipment status reviewed", "Barrier status reviewed", "Planned operation understood", "Relevant approved procedure available", "Open issues identified"]
    for item in defaults:
        conn.execute("INSERT OR IGNORE INTO pre_tour_checklist (item, done, updated_at) VALUES (?,?,?)", (item, 0, now_iso() if 'now_iso' in globals() else ''))
    conn.commit()
    conn.close()


def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


# ---------------------------------------------------------------------------
# API handlers — each returns a JSON-able python object
# ---------------------------------------------------------------------------

def api_get_job(conn):
    row = conn.execute("SELECT * FROM job_config WHERE id = 1").fetchone()
    return dict(row) if row else {}


def api_save_job(conn, body):
    fields = [
        "rig_name", "rig_type", "operator", "well_name", "location",
        "hole_sections", "casing_program", "current_section", "mud_system",
        "current_mud_weight", "units", "mpd_config", "rcd_config",
        "choke_arrangement", "sensor_locations", "flow_measurement_locations",
        "pressure_measurement_locations", "gas_handling_arrangement",
        "key_personnel", "communication_hierarchy",
        "approved_operating_limits", "procedure_references",
    ]
    values = {f: body.get(f, "") for f in fields}
    values["updated_at"] = now_iso()
    cols = ", ".join(values.keys())
    placeholders = ", ".join("?" for _ in values)
    updates = ", ".join(f"{k}=excluded.{k}" for k in values.keys())
    conn.execute(
        f"""INSERT INTO job_config (id, {cols}) VALUES (1, {placeholders})
            ON CONFLICT(id) DO UPDATE SET {updates}""",
        list(values.values()),
    )
    conn.commit()
    return api_get_job(conn)


def api_add_timeline(conn, body):
    conn.execute(
        """INSERT INTO timeline
           (ts, entry_type, operation, depth, pump_rate, sbp, spp, flow_out,
            pit_volume, equipment_status, notes)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (
            now_iso(),
            body.get("entry_type", "update"),
            body.get("operation", ""),
            body.get("depth", ""),
            body.get("pump_rate", ""),
            body.get("sbp", ""),
            body.get("spp", ""),
            body.get("flow_out", ""),
            body.get("pit_volume", ""),
            body.get("equipment_status", ""),
            body.get("notes", ""),
        ),
    )
    conn.commit()
    return {"ok": True}


def api_timeline(conn, limit=50):
    rows = conn.execute(
        "SELECT * FROM timeline ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    return [dict(r) for r in rows]


def api_catch_me_up(conn):
    rows = api_timeline(conn, limit=5)
    watch = [dict(r) for r in conn.execute(
        "SELECT * FROM watch_list WHERE resolved = 0 ORDER BY id DESC"
    ).fetchall()]
    last = rows[0] if rows else None
    minutes_since = None
    if last:
        try:
            last_dt = datetime.fromisoformat(last["ts"])
            minutes_since = round((datetime.now(last_dt.tzinfo) - last_dt).total_seconds() / 60)
        except Exception:
            minutes_since = None
    return {
        "last_entry": last,
        "minutes_since_last_update": minutes_since,
        "recent": rows,
        "watch_list": watch,
    }


def api_what_changed(conn):
    rows = api_timeline(conn, limit=2)
    if len(rows) < 2:
        return {"ok": False, "message": "Need at least two timeline entries to compare."}
    current, previous = rows[0], rows[1]
    fields = ["depth", "pump_rate", "sbp", "spp", "flow_out", "pit_volume"]
    diff = []
    for f in fields:
        cur_v, prev_v = current.get(f) or "", previous.get(f) or ""
        changed = cur_v != prev_v
        diff.append({"parameter": f, "previous": prev_v, "current": cur_v, "changed": changed})
    return {"ok": True, "previous_ts": previous["ts"], "current_ts": current["ts"], "diff": diff}


def api_since_last_tour(conn):
    tour_start = conn.execute(
        "SELECT * FROM timeline WHERE entry_type = 'tour_start' ORDER BY id DESC LIMIT 1"
    ).fetchone()
    current = conn.execute(
        "SELECT * FROM timeline ORDER BY id DESC LIMIT 1"
    ).fetchone()
    if not tour_start:
        return {"ok": False, "message": "No tour start marked yet. Use 'Mark Tour Start' at shift start."}
    since_rows = conn.execute(
        "SELECT * FROM timeline WHERE id > ? AND id != ? ORDER BY id ASC",
        (tour_start["id"], tour_start["id"]),
    ).fetchall()
    return {
        "ok": True,
        "tour_start": dict(tour_start),
        "current": dict(current) if current else None,
        "events_during_tour": [dict(r) for r in since_rows],
    }


def api_mark_tour_start(conn, body):
    body = dict(body)
    body["entry_type"] = "tour_start"
    return api_add_timeline(conn, body)


def api_watch_add(conn, body):
    conn.execute(
        "INSERT INTO watch_list (created_at, text, resolved) VALUES (?,?,0)",
        (now_iso(), body.get("text", "")),
    )
    conn.commit()
    return {"ok": True}


def api_watch_resolve(conn, item_id):
    conn.execute(
        "UPDATE watch_list SET resolved = 1, resolved_at = ? WHERE id = ?",
        (now_iso(), item_id),
    )
    conn.commit()
    return {"ok": True}


def api_watch_list(conn):
    rows = conn.execute(
        "SELECT * FROM watch_list ORDER BY resolved ASC, id DESC"
    ).fetchall()
    return [dict(r) for r in rows]


def api_meeting_brief(conn):
    job = api_get_job(conn)
    cmu = api_catch_me_up(conn)
    last = cmu["last_entry"]
    return {
        "well_name": job.get("well_name") or "NOT CONFIGURED",
        "rig_name": job.get("rig_name") or "NOT CONFIGURED",
        "current_section": job.get("current_section") or "NOT CONFIGURED",
        "operation": (last or {}).get("operation") or "No update logged yet",
        "depth": (last or {}).get("depth") or "—",
        "sbp": (last or {}).get("sbp") or "—",
        "pump_rate": (last or {}).get("pump_rate") or "—",
        "flow_out": (last or {}).get("flow_out") or "—",
        "last_event_notes": (last or {}).get("notes") or "—",
        "watch_items": cmu["watch_list"],
    }


def api_decision_add(conn, body):
    conn.execute(
        """INSERT INTO decision_log
           (ts, observation, confirmation, people_notified, procedure_reference,
            action_status, result, outstanding_item)
           VALUES (?,?,?,?,?,?,?,?)""",
        (
            now_iso(),
            body.get("observation", ""),
            body.get("confirmation", ""),
            body.get("people_notified", ""),
            body.get("procedure_reference", ""),
            body.get("action_status", ""),
            body.get("result", ""),
            body.get("outstanding_item", ""),
        ),
    )
    conn.commit()
    return {"ok": True}


def api_decision_log(conn):
    rows = conn.execute("SELECT * FROM decision_log ORDER BY id DESC").fetchall()
    return [dict(r) for r in rows]


def api_competency_list(conn):
    rows = conn.execute("SELECT * FROM competency ORDER BY topic ASC").fetchall()
    return [dict(r) for r in rows]


def api_competency_save(conn, body):
    topic = (body.get("topic") or "").strip()
    if not topic:
        return {"ok": False, "message": "Topic is required."}
    conn.execute(
        """INSERT INTO competency (topic, confidence, notes, updated_at)
           VALUES (?,?,?,?)
           ON CONFLICT(topic) DO UPDATE SET
             confidence=excluded.confidence, notes=excluded.notes, updated_at=excluded.updated_at""",
        (topic, body.get("confidence", ""), body.get("notes", ""), now_iso()),
    )
    conn.commit()
    return {"ok": True}


# Simple offline engineering calculators (pure functions, no invented limits)
def api_calc_hydrostatic(body):
    try:
        mw = float(body["mud_weight_ppg"])
        tvd = float(body["tvd_ft"])
    except (KeyError, ValueError):
        return {"ok": False, "message": "Provide mud_weight_ppg and tvd_ft as numbers."}
    hp = 0.052 * mw * tvd
    return {
        "ok": True,
        "formula": "HP (psi) = 0.052 x MW (ppg) x TVD (ft)",
        "inputs": {"mud_weight_ppg": mw, "tvd_ft": tvd},
        "answer_psi": round(hp, 1),
    }


def api_calc_emw(body):
    try:
        pressure = float(body["pressure_psi"])
        tvd = float(body["tvd_ft"])
    except (KeyError, ValueError):
        return {"ok": False, "message": "Provide pressure_psi and tvd_ft as numbers."}
    if tvd == 0:
        return {"ok": False, "message": "TVD cannot be zero."}
    emw = pressure / (0.052 * tvd)
    return {
        "ok": True,
        "formula": "EMW (ppg) = Pressure (psi) / (0.052 x TVD (ft))",
        "inputs": {"pressure_psi": pressure, "tvd_ft": tvd},
        "answer_ppg": round(emw, 2),
    }


def _numbers(body, *keys):
    """Pull required numeric fields from body; return (values_dict, error_or_None)."""
    values = {}
    for k in keys:
        try:
            values[k] = float(body[k])
        except (KeyError, ValueError, TypeError):
            return None, f"Provide {k} as a number."
    return values, None


def api_calc_annular_capacity(body):
    v, err = _numbers(body, "hole_id_in", "pipe_od_in")
    if err:
        return {"ok": False, "message": err}
    cap = (v["hole_id_in"] ** 2 - v["pipe_od_in"] ** 2) / 1029.4
    return {
        "ok": True,
        "formula": "Annular Capacity (bbl/ft) = (Hole ID^2 - Pipe OD^2) / 1029.4",
        "inputs": v,
        "answer_bbl_per_ft": round(cap, 5),
    }


def api_calc_pipe_capacity(body):
    v, err = _numbers(body, "pipe_id_in")
    if err:
        return {"ok": False, "message": err}
    cap = (v["pipe_id_in"] ** 2) / 1029.4
    return {
        "ok": True,
        "formula": "Pipe Capacity (bbl/ft) = Pipe ID^2 / 1029.4",
        "inputs": v,
        "answer_bbl_per_ft": round(cap, 5),
    }


def api_calc_annular_velocity(body):
    v, err = _numbers(body, "flow_rate_gpm", "hole_id_in", "pipe_od_in")
    if err:
        return {"ok": False, "message": err}
    denom = v["hole_id_in"] ** 2 - v["pipe_od_in"] ** 2
    if denom <= 0:
        return {"ok": False, "message": "Hole ID must be greater than pipe OD."}
    av = 24.5 * v["flow_rate_gpm"] / denom
    return {
        "ok": True,
        "formula": "Annular Velocity (ft/min) = 24.5 x Q (gpm) / (Hole ID^2 - Pipe OD^2)",
        "inputs": v,
        "answer_ft_per_min": round(av, 1),
    }


def api_calc_lag(body):
    v, err = _numbers(body, "annular_capacity_bbl_per_ft", "length_ft", "flow_rate_bbl_per_min")
    if err:
        return {"ok": False, "message": err}
    if v["flow_rate_bbl_per_min"] <= 0:
        return {"ok": False, "message": "Flow rate must be greater than zero."}
    volume = v["annular_capacity_bbl_per_ft"] * v["length_ft"]
    time_min = volume / v["flow_rate_bbl_per_min"]
    return {
        "ok": True,
        "formula": "Lag Volume (bbl) = Annular Capacity (bbl/ft) x Length (ft); Lag Time (min) = Lag Volume / Flow Rate (bbl/min)",
        "inputs": v,
        "answer_lag_volume_bbl": round(volume, 2),
        "answer_lag_time_min": round(time_min, 2),
    }


def api_calc_gradient(body):
    v, err = _numbers(body, "mud_weight_ppg")
    if err:
        return {"ok": False, "message": err}
    gradient = v["mud_weight_ppg"] * 0.052
    return {
        "ok": True,
        "formula": "Pressure Gradient (psi/ft) = MW (ppg) x 0.052",
        "inputs": v,
        "answer_psi_per_ft": round(gradient, 4),
    }


def api_calc_unit_convert(body):
    kind = body.get("kind")
    v, err = _numbers(body, "value")
    if err:
        return {"ok": False, "message": err}
    value = v["value"]
    table = {
        "ppg_to_sg": (value / 8.345, "SG", "SG = ppg / 8.345"),
        "sg_to_ppg": (value * 8.345, "ppg", "ppg = SG x 8.345"),
        "bbl_to_gal": (value * 42, "gal", "gal = bbl x 42"),
        "gal_to_bbl": (value / 42, "bbl", "bbl = gal / 42"),
        "ft_to_m": (value * 0.3048, "m", "m = ft x 0.3048"),
        "m_to_ft": (value / 0.3048, "ft", "ft = m / 0.3048"),
    }
    if kind not in table:
        return {"ok": False, "message": f"Unknown conversion kind '{kind}'."}
    answer, unit, formula = table[kind]
    return {"ok": True, "formula": formula, "inputs": {"value": value}, "answer": round(answer, 4), "unit": unit}


def api_barriers(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM barriers ORDER BY id DESC").fetchall()]
def api_barrier_save(conn, body):
    fields=["name","role","status","verified_at","verified_by","notes"]
    vals=[body.get(f, "") for f in fields]+[now_iso()]
    conn.execute("INSERT INTO barriers (name,role,status,verified_at,verified_by,notes,updated_at) VALUES (?,?,?,?,?,?,?)", vals)
    conn.commit(); return api_barriers(conn)
def api_checklist(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM pre_tour_checklist ORDER BY id").fetchall()]
def api_checklist_toggle(conn, item_id):
    conn.execute("UPDATE pre_tour_checklist SET done=1-done, updated_at=? WHERE id=?", (now_iso(), item_id)); conn.commit(); return api_checklist(conn)
def api_handover(conn):
    latest=conn.execute("SELECT * FROM timeline ORDER BY id DESC LIMIT 1").fetchone()
    watch=conn.execute("SELECT text FROM watch_list WHERE resolved=0 ORDER BY id DESC").fetchall()
    barriers=conn.execute("SELECT name,status FROM barriers ORDER BY id DESC").fetchall()
    return {"latest": dict(latest) if latest else {}, "watch_items":[r[0] for r in watch], "barriers":[dict(r) for r in barriers]}


# ---------------------------------------------------------------------------
# Assistant intelligence: confirmed-data memory, trends, fingerprints
# ---------------------------------------------------------------------------
def _latest_timeline(conn, n=20):
    return [dict(r) for r in conn.execute("SELECT * FROM timeline ORDER BY id DESC LIMIT ?", (n,)).fetchall()]

def _num(v):
    try: return float(str(v).strip())
    except Exception: return None

def api_save_assistant_state(conn, body):
    fields=["current_operation","status","trend","flow_status","pit_status","equipment_status","concern","mud_weight","notes"]
    vals={f: body.get(f,"") for f in fields}
    vals["updated_at"]=now_iso()
    cols=", ".join(vals); qs=", ".join("?" for _ in vals); upd=", ".join(f"{k}=excluded.{k}" for k in vals)
    conn.execute(f"INSERT INTO assistant_state (id,{cols}) VALUES (1,{qs}) ON CONFLICT(id) DO UPDATE SET {upd}", list(vals.values()))
    conn.commit()
    return api_get_assistant_state(conn)

def api_get_assistant_state(conn):
    r=conn.execute("SELECT * FROM assistant_state WHERE id=1").fetchone()
    return dict(r) if r else {}

def api_situation(conn):
    state=api_get_assistant_state(conn)
    rows=_latest_timeline(conn, 12)
    latest=rows[0] if rows else {}
    watch=[dict(r) for r in conn.execute("SELECT * FROM watch_list WHERE resolved=0 ORDER BY id DESC").fetchall()]
    barriers=[dict(r) for r in conn.execute("SELECT * FROM barriers ORDER BY id DESC").fetchall()]
    return {"state":state,"latest":latest,"recent":rows,"watch_items":watch,"barriers":barriers}

def _trend(rows, field):
    vals=[]
    for r in reversed(rows):
        n=_num(r.get(field))
        if n is not None: vals.append(n)
    if len(vals)<2: return {"direction":"insufficient data","delta":None,"count":len(vals)}
    d=vals[-1]-vals[0]
    eps=max(abs(vals[0])*0.002, 0.01)
    direction="increasing" if d>eps else "decreasing" if d<-eps else "stable"
    return {"direction":direction,"delta":round(d,3),"count":len(vals),"first":vals[0],"last":vals[-1]}

def api_trends(conn):
    rows=_latest_timeline(conn, 50)
    return {"rows":list(reversed(rows)),"trends":{f:_trend(rows,f) for f in ["depth","pump_rate","sbp","spp","flow_out","pit_volume"]}}

def api_fingerprint(conn):
    rows=_latest_timeline(conn, 12)
    s=api_get_assistant_state(conn)
    latest=rows[0] if rows else {}
    return {
      "operation":s.get("current_operation") or latest.get("operation") or "Not set",
      "trend":s.get("trend") or "Not set",
      "flow":s.get("flow_status") or "Not set",
      "pits":s.get("pit_status") or "Not set",
      "equipment":s.get("equipment_status") or latest.get("equipment_status") or "Not set",
      "concern":s.get("concern") or "Not set",
      "sbp_pattern":_trend(rows,"sbp"),
      "flow_pattern":_trend(rows,"flow_out"),
      "pit_pattern":_trend(rows,"pit_volume"),
      "recent_event":latest.get("notes","") if latest else ""
    }

def api_assistant(conn, body):
    q=(body.get("query") or "").strip().lower()
    sit=api_situation(conn); fp=api_fingerprint(conn)
    state=sit["state"]; latest=sit["latest"]
    changed=api_what_changed(conn)
    op=fp["operation"]
    response={
      "what_i_understand": f"Current operation: {op}. Status: {state.get('status') or 'Unknown'}.",
      "current_situation": {"operation":op,"latest_update":latest.get("notes") or "No narrative update recorded","open_watch_items":len(sit["watch_items"])},
      "what_changed": changed.get("diff",[]) if changed.get("ok") else [],
      "what_to_check":["Confirm current readings against the approved job procedure and operating envelope.","Verify sensor/data quality before acting on a trend.","Review open watch items and barrier status."],
      "questions_to_ask":["What changed immediately before the trend or concern?","Are independent measurements consistent?","What does the approved procedure require for this condition?"],
      "what_to_communicate":f"Current operation is {op}. State the confirmed trend, relevant observations, and any open concern; avoid assumptions.",
      "what_to_record":"Record time, operation, confirmed readings, observations, people notified, procedure reference, and outcome.",
      "safety_note":"This assistant organizes confirmed information and trend patterns. It does not diagnose a kick, ballooning, losses, or prescribe safety-critical actions."
    }
    if "meeting" in q or "pre-job" in q or "brief" in q:
        response["what_to_communicate"]=f"Pre-job briefing: confirm the operation ({op}), responsibilities, communication, monitoring points, expected responses from the approved procedure, stop/escalation criteria, and questions from the crew."
    elif "handover" in q:
        response["what_to_communicate"]="Handover: state current operation, latest confirmed condition, significant events, trends, open watch items, barrier status, equipment issues, decisions, and required follow-up."
    elif "driller" in q:
        response["what_to_communicate"]=f"To the driller: briefly state the confirmed observation, current operation ({op}), what you are monitoring, and that any action follows the approved procedure and agreed communication chain."
    return response

def api_tour_brief(conn):
    sit=api_situation(conn); rows=_latest_timeline(conn,8)
    return {"current":sit["state"],"latest":sit["latest"],"recent_events":rows,"open_watch_items":sit["watch_items"],"barriers":sit["barriers"],
            "questions_for_outgoing":["What changed since the last stable period?","What remains open?","Any equipment or data-quality concerns?","Any barrier status change?","What is the next planned operation?"]}

def api_lesson_add(conn, body):
    conn.execute("INSERT INTO lessons (ts,happened,confusing,lesson,remember) VALUES (?,?,?,?,?)",
      (now_iso(),body.get("happened",""),body.get("confusing",""),body.get("lesson",""),body.get("remember","")))
    conn.commit(); return {"ok":True}

def api_lessons(conn):
    return [dict(r) for r in conn.execute("SELECT * FROM lessons ORDER BY id DESC LIMIT 100").fetchall()]


ROUTES_GET = {
    "/api/job": api_get_job,
    "/api/timeline": api_timeline,
    "/api/catch-me-up": api_catch_me_up,
    "/api/what-changed": api_what_changed,
    "/api/since-last-tour": api_since_last_tour,
    "/api/watch-list": api_watch_list,
    "/api/meeting-brief": api_meeting_brief,
    "/api/decision-log": api_decision_log,
    "/api/competency": api_competency_list,
    "/api/barriers": api_barriers,
    "/api/pre-tour-checklist": api_checklist,
    "/api/handover": api_handover,
    "/api/assistant-state": api_get_assistant_state,
    "/api/situation": api_situation,
    "/api/trends": api_trends,
    "/api/fingerprint": api_fingerprint,
    "/api/tour-brief": api_tour_brief,
    "/api/lessons": api_lessons,
}

ROUTES_POST = {
    "/api/job": api_save_job,
    "/api/timeline": api_add_timeline,
    "/api/tour-start": api_mark_tour_start,
    "/api/watch-list": api_watch_add,
    "/api/decision-log": api_decision_add,
    "/api/competency": api_competency_save,
    "/api/barriers": api_barrier_save,
    "/api/assistant-state": api_save_assistant_state,
    "/api/ask-partner": api_assistant,
    "/api/lessons": api_lesson_add,
    "/api/calc/hydrostatic": api_calc_hydrostatic,
    "/api/calc/emw": api_calc_emw,
    "/api/calc/annular-capacity": api_calc_annular_capacity,
    "/api/calc/pipe-capacity": api_calc_pipe_capacity,
    "/api/calc/annular-velocity": api_calc_annular_velocity,
    "/api/calc/lag": api_calc_lag,
    "/api/calc/gradient": api_calc_gradient,
    "/api/calc/unit-convert": api_calc_unit_convert,
}

CALC_ROUTES = {
    "/api/calc/hydrostatic", "/api/calc/emw", "/api/calc/annular-capacity",
    "/api/calc/pipe-capacity", "/api/calc/annular-velocity", "/api/calc/lag",
    "/api/calc/gradient", "/api/calc/unit-convert",
}


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC_DIR), **kwargs)

    def _send_json(self, obj, status=200):
        payload = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in ROUTES_GET:
            conn = get_db()
            try:
                qs = urllib.parse.parse_qs(parsed.query)
                if parsed.path == "/api/timeline" and "limit" in qs:
                    result = ROUTES_GET[parsed.path](conn, int(qs["limit"][0]))
                elif parsed.path == "/api/watch-list/resolve":
                    result = {"ok": False}
                else:
                    result = ROUTES_GET[parsed.path](conn)
                self._send_json(result)
            finally:
                conn.close()
            return
        if parsed.path.startswith("/api/pre-tour-checklist/") and parsed.path.endswith("/toggle"):
            item_id = parsed.path.split("/")[3]
            conn = get_db()
            try:
                self._send_json(api_checklist_toggle(conn, item_id))
            finally:
                conn.close()
            return
        if parsed.path.startswith("/api/watch-list/") and parsed.path.endswith("/resolve"):
            item_id = parsed.path.split("/")[3]
            conn = get_db()
            try:
                result = api_watch_resolve(conn, item_id)
                self._send_json(result)
            finally:
                conn.close()
            return
        # fall back to static file serving
        if parsed.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except json.JSONDecodeError:
            body = {}

        if parsed.path in CALC_ROUTES:
            result = ROUTES_POST[parsed.path](body)
            self._send_json(result)
            return

        if parsed.path in ROUTES_POST:
            conn = get_db()
            try:
                result = ROUTES_POST[parsed.path](conn, body)
                self._send_json(result)
            finally:
                conn.close()
            return

        self._send_json({"error": "not found"}, status=404)

    def log_message(self, format, *args):
        # Quiet, single-line request logging instead of the default verbose format
        pass


def main():
    init_db()
    with socketserver.TCPServer(("127.0.0.1", PORT), Handler) as httpd:
        print(f"MPD PARTNER running at http://localhost:{PORT}")
        print("Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopped.")


def start_android_server(db_dir=None, port=8765):
    """Start MPD Partner HTTP server for the embedded Android runtime."""
    global DB_PATH
    if db_dir:
        DB_PATH = os.path.join(db_dir, "mpd_partner.db")
    init_db()
    server = http.server.ThreadingHTTPServer(("127.0.0.1", int(port)), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return True

if __name__ == "__main__":
    main()
