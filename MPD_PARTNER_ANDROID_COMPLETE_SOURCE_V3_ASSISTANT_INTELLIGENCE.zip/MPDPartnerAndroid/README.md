# MPD PARTNER Android

This is a self-contained Android project based on the uploaded MPD Partner v1 source.

Architecture:
- Android WebView UI
- Embedded Python runtime via Chaquopy
- Existing `app.py` JSON API
- SQLite database stored in Android app-private files
- Server binds only to `127.0.0.1`
- No laptop or external internet is required at runtime

The Python server starts automatically when the Android app launches.

## Build
Open this folder in Android Studio and build `app:assembleDebug`, or push it to a GitHub repository and use the included GitHub Actions workflow.

The resulting file is:
`app/build/outputs/apk/debug/app-debug.apk`

The source app remains unchanged in `../source/mpd_partner`.
